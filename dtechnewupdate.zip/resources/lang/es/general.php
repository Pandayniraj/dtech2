<?php

return [

    'text'              => [
        'welcome'   => 'Bienvenido',
    ],

];
