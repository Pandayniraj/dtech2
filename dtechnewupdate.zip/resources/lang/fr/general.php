<?php

return [

    'text'              => [
        'welcome'   => 'Bienvenue',
    ],

];
