<?php

return [

    'delete-confirm'              => [
        'title'   => 'Delete project',
        'body'    => 'Are you sure that you want to delete project ID :id with the name ":name"? This operation is irreversible.',
    ],

];
