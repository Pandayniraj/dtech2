<?php

return [

    'delete-confirm'              => [
        'title'   => 'Delete contact',
        'body'    => 'Are you sure that you want to delete contact ID :id with the name ":name"? This operation is irreversible.',
    ],

];
