<?php

return [

    'delete-confirm'              => [
        'title'   => 'Delete Ticket',
        'body'    => 'Are you sure you want to delete Ticket With Number',
    ],

];
