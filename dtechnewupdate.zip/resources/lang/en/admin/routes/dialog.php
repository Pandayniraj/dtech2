<?php

return [

    'delete-confirm'              => [
        'title'   => 'Delete route',
        'body'    => 'Are you sure that you want to delete route ID :id with the name ":name"? This operation is irreversible.',
    ],

];
