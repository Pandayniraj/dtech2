<?php

return [

    'delete-confirm'              => [
        'title'   => 'Delete case',
        'body'    => 'Are you sure that you want to delete case ID :id with the name ":name"? This operation is irreversible.',
    ],

];
