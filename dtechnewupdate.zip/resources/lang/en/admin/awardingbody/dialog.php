<?php

return [

    'delete-confirm'              => [
        'title'   => 'Delete Awarding Body',
        'body'    => 'Are you sure that you want to delete awardingbody ID :id with the name ":name"? This operation is irreversible.',
    ],

];
